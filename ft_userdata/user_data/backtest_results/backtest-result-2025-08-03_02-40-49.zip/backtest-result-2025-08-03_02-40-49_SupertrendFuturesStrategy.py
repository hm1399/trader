from freqtrade.strategy import IStrategy, merge_informative_pair
from pandas import DataFrame
import numpy as np


class SupertrendFuturesStrategy(IStrategy):
    """
    使用 Supertrend 的期貨雙向策略（支援做多做空）
    - 可用於 Binance Futures
    - 買入訊號：Supertrend 買入點
    - 做空訊號：Supertrend 賣出點
    """

    INTERFACE_VERSION = 3
    timeframe = '15m'
    can_short = True  # ✅ 啟用做空

    minimal_roi = {"0": 99}
    stoploss = -99
    trailing_stop = False

    process_only_new_candles = True
    startup_candle_count: int = 30

    # Supertrend 參數
    atr_period = 10
    atr_multiplier = 3.0
    use_ema_atr = False  # True: 使用 EMA, False: 使用 SMA

    def populate_indicators(self, df: DataFrame, metadata: dict) -> DataFrame:
        df = self.supertrend(df, self.atr_period, self.atr_multiplier, self.use_ema_atr)
        return df

    def populate_entry_trend(self, df: DataFrame, metadata: dict) -> DataFrame:
        # 做多買入訊號
        #freqtrade download-data --exchange binance --pairs ".*/USDT:USDT" --timeframes 15m --timerange 20250701-20250802
        #freqtrade backtesting --strategy SupertrendFuturesStrategy --timeframe 15m --dry-run-wallet 72 --timerange=20250701-20250802
        df.loc[
            (df['supertrend_buy']),
            'enter_long'
        ] = 1
        df.loc[
            (df['supertrend_buy']),
            'exit_short'
        ] = 1
        return df

    def populate_exit_trend(self, df: DataFrame, metadata: dict) -> DataFrame:
        # 做空開倉訊號（對應為賣出趨勢）
        df.loc[
            (df['supertrend_sell']),
            'enter_short'
        ] = 1
        df.loc[
            (df['supertrend_sell']),
            'exit_long'
        ] = 1
        
        return df

    def supertrend(self, df: DataFrame, period: int = 10, multiplier: float = 3.0, use_ema: bool = True) -> DataFrame:
        """
        Pine Script Supertrend 指標轉換為 Pandas
        """
        df = df.copy()
        df['hl'] = df['high'] - df['low']
        df['hc'] = abs(df['high'] - df['close'].shift())
        df['lc'] = abs(df['low'] - df['close'].shift())
        df['tr'] = df[['hl', 'hc', 'lc']].max(axis=1)

        # ATR 計算
        if use_ema:
            df['atr'] = df['tr'].ewm(span=period, min_periods=period).mean()
        else:
            df['atr'] = df['tr'].rolling(window=period, min_periods=1).mean()

        df['hl2'] = (df['high'] + df['low']) / 2
        df['upperband'] = df['hl2'] - (multiplier * df['atr'])
        df['lowerband'] = df['hl2'] + (multiplier * df['atr'])

        # 初始化趨勢
        df['trend'] = 1
        for i in range(1, len(df)):
            prev_close = df.at[i - 1, 'close']
            prev_upper = df.at[i - 1, 'upperband']
            prev_lower = df.at[i - 1, 'lowerband']
            prev_trend = df.at[i - 1, 'trend']
            curr_upper = df.at[i, 'upperband']
            curr_lower = df.at[i, 'lowerband']
            curr_close = df.at[i, 'close']

            if prev_trend == 1:
                if curr_close < prev_upper:
                    df.at[i, 'trend'] = -1
                else:
                    df.at[i, 'trend'] = 1
                    df.at[i, 'upperband'] = max(curr_upper, prev_upper)
            else:
                if curr_close > prev_lower:
                    df.at[i, 'trend'] = 1
                else:
                    df.at[i, 'trend'] = -1
                    df.at[i, 'lowerband'] = min(curr_lower, prev_lower)

        # 訊號產生
        df['supertrend'] = df['trend']
        df['supertrend_buy'] = (df['trend'] == 1) & (df['trend'].shift(1) == -1)
        df['supertrend_sell'] = (df['trend'] == -1) & (df['trend'].shift(1) == 1)

        # 移除中間變量
        df.drop(columns=['hl', 'hc', 'lc', 'tr', 'hl2'], inplace=True)

        return df
