from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta


class MFIStrategy(IStrategy):
    """
    MFI 策略（支持加仓）:
    - 买入：每次 MFI < 10 即触发加仓信号
    - 卖出：MFI > 90 全部卖出
    - 允许多次加仓（通过 freqtrade 的 `max_open_trades` + `entry_tag` 控制）
    """

    INTERFACE_VERSION = 3

    # 频率设置，例如 '5m', '1h'
    timeframe = '5m'

    # 策略参数
    minimal_roi = {"0": 0.01}
    stoploss = -0.04
    trailing_stop = False
    use_custom_stoploss = False
    process_only_new_candles = True

    # 启动时所需的历史K线数量
    startup_candle_count: int = 30

    # 支持加仓（每次新买入的交易都被允许）
    position_adjustment_enable = True

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['mfi'] = ta.MFI(dataframe)
        return dataframe

    def populate_buy_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 初始开仓与加仓条件一样
        dataframe.loc[
            (dataframe['mfi'] < 10),
            'buy'] = 1
        return dataframe

    def populate_sell_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (dataframe['mfi'] > 90),
            'sell'] = 1
        return dataframe

    def adjust_trade_position(self, trade, current_time, current_rate, current_profit, **kwargs):
        dataframe, _ = self.dp.get_analyzed_dataframe(trade.pair, self.timeframe)
        last_row = dataframe.iloc[-1]

        if last_row is None or 'mfi' not in last_row:
            return None

        if last_row['mfi'] < 10:
            # 例如每次加仓减小 20%
            max_stake = trade.stake_amount
            num_fills = len(trade.fills)  # 第一次为 0，加仓第1次为1...
            next_stake = max_stake * (0.8 ** num_fills)
            return next_stake

        return None
