# --- Freqtrade Strategy Template ---
from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta


class MFIStrategy(IStrategy):
    """
    简单的 MFI 极端值策略：
    - 买入：MFI < 10
    - 卖出：MFI > 90
    """
    INTERFACE_VERSION = 3

    # Timeframe, e.g., 1h, 5m
    timeframe = '5m'

    # Strategy parameters
    minimal_roi = {"0": 0.1}
    stoploss = -0.15
    trailing_stop = False
    process_only_new_candles = True
    use_custom_stoploss = False
    startup_candle_count: int = 30

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:

        dataframe['mfi'] = ta.MFI(dataframe)
        return dataframe

    def populate_buy_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['mfi'] < 10)
            ),
            'buy'] = 1
        return dataframe

    def populate_sell_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        
        return dataframe
