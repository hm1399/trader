# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# flake8: noqa: F401
# isort: skip_file
# --- Do not remove these imports ---
import numpy as np
import pandas as pd
from datetime import datetime, timedelta, timezone
from pandas import DataFrame
from typing import Optional, Union

from freqtrade.strategy import (
    IStrategy,
    Trade,
    Order,
    PairLocks,
    informative,  # @informative decorator
    # Hyperopt Parameters
    BooleanParameter,
    CategoricalParameter,
    DecimalParameter,
    IntParameter,
    RealParameter,
    # timeframe helpers
    timeframe_to_minutes,
    timeframe_to_next_date,
    timeframe_to_prev_date,
    # Strategy helper functions
    merge_informative_pair,
    stoploss_from_absolute,
    stoploss_from_open,
)

# --------------------------------
# Add your lib to import here
import talib.abstract as ta
from technical import qtpylib


# This class is a sample. Feel free to customize it.
class SuperTrendStrategy(IStrategy):

    # Strategy interface version - allow new iterations of the strategy interface.
    # Check the documentation or the Sample strategy to get the latest version.
    INTERFACE_VERSION = 3

    # Can this strategy go short?
    can_short: bool = False 

    # Minimal ROI designed for the strategy.
    # This attribute will be overridden if the config file contains "minimal_roi".
    minimal_roi = {
        "0":100,    #disable
    }

    # Optimal stoploss designed for the strategy.
    # This attribute will be overridden if the config file contains "stoploss".
    stoploss = -100 #disable

    # Trailing stoploss
    trailing_stop = False
    # trailing_only_offset_is_reached = False
    # trailing_stop_positive = 0.01
    # trailing_stop_positive_offset = 0.0  # Disabled / not configured

    # Optimal timeframe for the strategy.
    timeframe = "15m"

    # Run "populate_indicators()" only for new candle.
    process_only_new_candles = True

    # These values can be overridden in the config.
    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = False

    # parameters
    Periods = 10
    src = 'hl2' #from Pine script (high+low)/2
    Multiplier = 3.0
    changeATR = True
    showsignals = True
    highlighting = True
    # Number of candles the strategy requires before producing valid signals
    startup_candle_count: int = 200

    # Optional order type mapping.
    order_types = {
        "entry": "limit",
        "exit": "limit",
        "stoploss": "market",
        "stoploss_on_exchange": False,
    }

    # Optional order time in force.
    order_time_in_force = {"entry": "GTC", "exit": "GTC"}

    def informative_pairs(self):
        """
        輔助交易對
        Define additional, informative pair/interval combinations to be cached from the exchange.
        These pair/interval combinations are non-tradeable, unless they are part
        of the whitelist as well.
        For more information, please consult the documentation
        :return: List of tuples in the format (pair, interval)
            Sample: return [("ETH/USDT", "5m"),
                            ("BTC/USDT", "15m"),
                            ]
        """
        return []

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Adds several different TA indicators to the given DataFrame

        Performance Note: For the best performance be frugal on the number of indicators
        you are using. Let uncomment only the indicator you are using in your strategies
        or your hyperopt configuration, otherwise you will waste your memory and CPU usage.
        :param dataframe: Dataframe with data from the exchange
        :param metadata: Additional information, like the currently traded pair
        :return: a Dataframe with all mandatory indicators for the strategies
        """

        atr2 = ta.SMA(dataframe, timeperiod=self.Periods)
        
        if self.changeATR==True : 
            dataframe['atr'] = ta.ATR(dataframe['high'], dataframe['low'], dataframe['close'], timeperiod=self.Periods)
        else:
            dataframe['atr'] = atr2


        if(self.src == 'hl2'):
            up = (dataframe['high']+dataframe['low'])/2 - self.Multiplier * dataframe['atr']
        dataframe['up1'] = up.shift(1)  # 獲取前一根 K 線的 dn 值
        dataframe['up1'].fillna(up, inplace=True)  # 如果 dn1 是 NaN，則使用當前的 dn 值

        # 根據條件更新 dn 值
        dataframe['up'] = np.where(dataframe['close'].shift(1) > dataframe['up1'], 
                            np.minimum(up, dataframe['up1']),
                            up)




        if(self.src == 'hl2'):
            dn = (dataframe['high']+dataframe['low'])/2 + self.Multiplier * dataframe['atr']
        dataframe['dn1'] = dn.shift(1)  # 獲取前一根 K 線的 dn 值
        dataframe['dn1'].fillna(dn, inplace=True)  # 如果 dn1 是 NaN，則使用當前的 dn 值

        # 根據條件更新 dn 值
        dataframe['dn'] = np.where(dataframe['close'].shift(1) < dataframe['dn1'], 
                            np.minimum(dn, dataframe['dn1']),
                            dn)
        
        dataframe['trend'] = 1
        # 使用 shift() 來獲取前一根 K 線的 'trend' 值
        dataframe['trend'] = dataframe['trend'].shift(1)
        # 如果 trend 是 NaN，則使用當前的 'trend' 值填充
        dataframe['trend'].fillna(dataframe['trend'], inplace=True)
        # 根據條件更新 'trend' 值
        dataframe['trend'] = np.where((dataframe['trend'] == -1) & (dataframe['close'] > dataframe['dn1']), 1,
                                    np.where((dataframe['trend'] == 1) & (dataframe['close'] < dataframe['up1']), -1,
                                    dataframe['trend']))
        
        trend_shifted = dataframe['trend'].shift(1)

        # 計算買入信號：當 trend 為 1 且 trend[1] 為 -1 時
        dataframe['buySignal'] = (dataframe['trend'] == 1) & (trend_shifted == -1)

        # 計算賣出信號：當 trend 為 -1 且 trend[1] 為 1 時
        dataframe['sellSignal'] = (dataframe['trend'] == -1) & (trend_shifted == 1)


        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Based on TA indicators, populates the entry signal for the given dataframe
        :param dataframe: DataFrame
        :param metadata: Additional information, like the currently traded pair
        :return: DataFrame with entry columns populated
        """
        dataframe.loc[
            (
                dataframe['buySignal'] == 1
            ),
            "enter_long",
        ] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Based on TA indicators, populates the exit signal for the given dataframe
        :param dataframe: DataFrame
        :param metadata: Additional information, like the currently traded pair
        :return: DataFrame with exit columns populated
        """
        dataframe.loc[
            (
                dataframe['sellSignal'] == 1
            ),
            "exit_long",
        ] = 1

        return dataframe
